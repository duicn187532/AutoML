/* ========= 全域狀態 ========= */
let rawData = [], columns = [];
let meta = null, tfModel = null;              // tfModel 只在 TF.js 模型時使用
let traditionalModel = null;                  // 傳統 ML 模型放這裡（本頁記憶體）
let charts = { loss: null, acc: null };
let lastPredRows = [];

/* ========= 小工具 ========= */
function isNumeric(v){ if(v===null||v===undefined||v==='') return false; return !isNaN(parseFloat(v)) && isFinite(v); }
function unique(arr){ return Array.from(new Set(arr)); }
function toCSV(rows){ if(!rows.length) return ''; const header=Object.keys(rows[0]); const out=[header.join(',')]; for(const r of rows) out.push(header.map(k=>r[k]).join(',')); return out.join('\n'); }
function downloadBlob(filename, content, mime='text/plain'){ const blob=new Blob([content],{type:mime}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=filename; a.click(); URL.revokeObjectURL(a.href); }
function renderTable(elId, rows){ const el=document.getElementById(elId); if(!rows.length){ el.innerHTML='<div class="muted">無資料</div>'; return; } const cols=Object.keys(rows[0]); const head='<tr>'+cols.map(c=>`<th>${c}</th>`).join('')+'</tr>'; const body=rows.map(r=>'<tr>'+cols.map(c=>`<td>${r[c]}</td>`).join('')+'</tr>').join(''); el.innerHTML=`<table><thead>${head}</thead><tbody>${body}</tbody></table>`; }
function trainTestSplit(X,y,ratio=0.8){ const n=X.length, idx=[...Array(n).keys()]; for(let i=n-1;i>0;i--){const j=Math.floor(Math.random()*(i+1)); [idx[i],idx[j]]=[idx[j],idx[i]];} const cut=Math.floor(n*ratio); const tr=idx.slice(0,cut), te=idx.slice(cut); return { Xtr:tr.map(i=>X[i]), ytr:tr.map(i=>y[i]), Xte:te.map(i=>X[i]), yte:te.map(i=>y[i]) }; }

/* ========= 前處理 ========= */
function inferTaskFromY(yRaw){
  const numy=yRaw.filter(isNumeric).length, uniq=unique(yRaw);
  if(numy<yRaw.length || uniq.length<=Math.min(20, yRaw.length/5)) return 'classification';
  return 'regression';
}
function buildPreprocessor(data, target, normalize=true){
  const allCols=Object.keys(data[0]);
  const featureCols=allCols.filter(c=>c!==target);
  const colTypes={}, catMaps={}, numStats={};
  // 自動欄位型態
  for(const c of featureCols){
    const sample=data.map(r=>r[c]).slice(0,200);
    const numCount=sample.filter(isNumeric).length;
    colTypes[c]=(numCount===sample.length)?'numeric':'category';
  }
  // 數值統計（同時備好 MinMax 與 Z-score 需要的參數）
  for(const c of featureCols.filter(c=>colTypes[c]==='numeric')){
    const vec=data.map(r=>{ const v=parseFloat(r[c]); return isFinite(v)?v:0; });
    const mn=Math.min(...vec), mx=Math.max(...vec);
    const range=(mx-mn)||1;
    const mean=vec.reduce((a,b)=>a+b,0)/vec.length;
    const std=Math.sqrt(vec.reduce((a,b)=>a+Math.pow(b-mean,2),0)/vec.length)||1;
    numStats[c]={min:mn, max:mx, range, mean, std};
  }
  // 類別 one-hot 映射
  for(const c of featureCols.filter(c=>colTypes[c]==='category')){
    const cats=unique(data.map(r=>r[c] ?? ''));
    catMaps[c]={}; cats.forEach((v,i)=>catMaps[c][v]=i);
  }
  return { featureCols, colTypes, catMaps, numStats, normalize };
}
function transformFeatures(data, meta){
  const { featureCols, colTypes, catMaps, numStats, normalize } = meta;
  const out=[];
  for(const r of data){
    let row=[];
    for(const c of featureCols){
      if(colTypes[c]==='numeric'){
        let v=parseFloat(r[c]); if(!isFinite(v)) v=0;
        if(normalize){ const {min,range}=numStats[c]; v=(v-min)/range; } // MinMax
        else { const {mean,std}=numStats[c]; v=(v-mean)/std; }          // Z-score
        row.push(v);
      }else{
        const map=catMaps[c], dim=Object.keys(map).length;
        const vec=new Array(dim).fill(0), idx=map[r[c]];
        if(idx!==undefined) vec[idx]=1;
        row=row.concat(vec);
      }
    }
    out.push(row);
  }
  return out;
}
function buildLabelMapping(yRaw){
  const isAllNum=yRaw.every(isNumeric); const uniq=unique(yRaw);
  if(!isAllNum || uniq.length<=Math.min(20, yRaw.length/5)){ const map={}; uniq.forEach((v,i)=>map[v]=i); return {task:'classification', map, classes:uniq}; }
  return {task:'regression'};
}
function prepareXY(data, target, normalize){
    const yRaw=data.map(r=>r[target]);
  
    // 從表格讀取欄位設定
    const rows=[...document.querySelectorAll('#varTable tbody tr')];
    const featureCols=[];
    const colTypes={};
  
    rows.forEach(row=>{
      const colName=row.cells[0].textContent;
      const typeSel=row.cells[1].querySelector('select').value;
      const useFeat=row.cells[2].querySelector('input').checked;
  
      if(colName!==target && useFeat){
        featureCols.push(colName);
        if(typeSel==='auto'){
          // 自動判斷
          const sample=data.map(r=>r[colName]).slice(0,200);
          const numCount=sample.filter(isNumeric).length;
          colTypes[colName]=(numCount===sample.length)?'numeric':'category';
        }else{
          colTypes[colName]=typeSel;
        }
      }
    });
  
    // 建立 Preprocessor
    const prep=buildPreprocessorCustom(data, target, featureCols, colTypes, normalize);
  
    const X=transformFeatures(data, prep);
    let y, labelInfo=null;
    let task=document.getElementById('taskSelect').value;
    if(task==='auto') task=inferTaskFromY(yRaw);
    if(task==='classification'){ 
      labelInfo=buildLabelMapping(yRaw); 
      y=yRaw.map(v=>labelInfo.map[v]); 
      prep.labelInfo=labelInfo; 
    } else { 
      y=yRaw.map(v=>parseFloat(v)); 
    }
    return { X, y, meta:{...prep, targetCol:target, task} };
  }
  
  // 新的 buildPreprocessorCustom
  function buildPreprocessorCustom(data, target, featureCols, colTypes, normalize=true){
    const catMaps={}, numStats={};
  
    // 數值欄位
    for(const c of featureCols.filter(c=>colTypes[c]==='numeric')){
      const vec=data.map(r=>{ const v=parseFloat(r[c]); return isFinite(v)?v:0; });
      const mn=Math.min(...vec), mx=Math.max(...vec);
      const range=(mx-mn)||1;
      const mean=vec.reduce((a,b)=>a+b,0)/vec.length;
      const std=Math.sqrt(vec.reduce((a,b)=>a+Math.pow(b-mean,2),0)/vec.length)||1;
      numStats[c]={min:mn, max:mx, range, mean, std};
    }
  
    // 類別欄位
    for(const c of featureCols.filter(c=>colTypes[c]==='category')){
      const cats=unique(data.map(r=>r[c] ?? ''));
      catMaps[c]={}; cats.forEach((v,i)=>catMaps[c][v]=i);
    }
  
    return { featureCols, colTypes, catMaps, numStats, normalize };
  }
  
/* ========= 傳統 ML：簡單前端實作 ========= */
// 決策樹（分類）
const { DecisionTreeClassifier, DecisionTreeRegression, RandomForestClassifier, RandomForestRegression, KNN, SVM, NaiveBayes } = MLBundle;

/* ========= TF.js 建模 ========= */
function makeModel(inputDim, task, modelType, nClasses=2, lr=1e-3){
  const model=tf.sequential(); const opt=tf.train.adam(lr);
  if(task==='classification'){
    const binary=(nClasses===2);
    if(modelType==='linear' && binary) modelType='logistic';
    if(modelType==='auto') modelType=binary?'logistic':'mlp';
    if(modelType==='logistic'){
      model.add(tf.layers.dense({inputShape:[inputDim], units:binary?1:nClasses, activation:binary?'sigmoid':'softmax'}));
      model.compile({optimizer:opt, loss:binary?'binaryCrossentropy':'sparseCategoricalCrossentropy', metrics:['accuracy']});
    }else if(modelType==='deepmlp'){
      model.add(tf.layers.dense({inputShape:[inputDim], units:128, activation:'relu'}));
      model.add(tf.layers.dropout({rate:0.3}));
      model.add(tf.layers.dense({units:64, activation:'relu'}));
      model.add(tf.layers.dropout({rate:0.2}));
      model.add(tf.layers.dense({units:32, activation:'relu'}));
      model.add(tf.layers.dense({units:binary?1:nClasses, activation:binary?'sigmoid':'softmax'}));
      model.compile({optimizer:opt, loss:binary?'binaryCrossentropy':'sparseCategoricalCrossentropy', metrics:['accuracy']});
    }else if(modelType==='tabnet'){ // 簡化版
      model.add(tf.layers.dense({inputShape:[inputDim], units:inputDim, activation:'linear'}));
      model.add(tf.layers.dense({units:64, activation:'relu'}));
      model.add(tf.layers.dropout({rate:0.1}));
      model.add(tf.layers.dense({units:32, activation:'relu'}));
      model.add(tf.layers.dense({units:binary?1:nClasses, activation:binary?'sigmoid':'softmax'}));
      model.compile({optimizer:opt, loss:binary?'binaryCrossentropy':'sparseCategoricalCrossentropy', metrics:['accuracy']});
    }else{ // mlp
      model.add(tf.layers.dense({inputShape:[inputDim], units:64, activation:'relu'}));
      model.add(tf.layers.dropout({rate:0.2}));
      model.add(tf.layers.dense({units:32, activation:'relu'}));
      model.add(tf.layers.dense({units:binary?1:nClasses, activation:binary?'sigmoid':'softmax'}));
      model.compile({optimizer:opt, loss:binary?'binaryCrossentropy':'sparseCategoricalCrossentropy', metrics:['accuracy']});
    }
  }else{
    if(modelType==='auto') modelType='linear';
    if(modelType==='linear'){
      model.add(tf.layers.dense({inputShape:[inputDim], units:1, activation:'linear'}));
    }else if(modelType==='deepmlp'){
      model.add(tf.layers.dense({inputShape:[inputDim], units:128, activation:'relu'}));
      model.add(tf.layers.dropout({rate:0.3}));
      model.add(tf.layers.dense({units:64, activation:'relu'}));
      model.add(tf.layers.dropout({rate:0.2}));
      model.add(tf.layers.dense({units:32, activation:'relu'}));
      model.add(tf.layers.dense({units:1, activation:'linear'}));
    }else if(modelType==='poly'){
      model.add(tf.layers.dense({inputShape:[inputDim], units:inputDim*2, activation:'relu'}));
      model.add(tf.layers.dense({units:1, activation:'linear'}));
    }else{
      model.add(tf.layers.dense({inputShape:[inputDim], units:64, activation:'relu'}));
      model.add(tf.layers.dropout({rate:0.2}));
      model.add(tf.layers.dense({units:32, activation:'relu'}));
      model.add(tf.layers.dense({units:1, activation:'linear'}));
    }
    model.compile({optimizer:opt, loss:'meanSquaredError'});
  }
  return model;
}

/* ========= 圖表 ========= */
let chartsInit=false;
function ensureCharts(){
  if(chartsInit) return; chartsInit=true;
  charts.loss=new Chart(document.getElementById('lossChart'),{type:'line',data:{labels:[],datasets:[{label:'Val Loss',data:[],borderColor:'#e74c3c',backgroundColor:'rgba(231,76,60,.1)'}]},options:{responsive:true,animation:false}});
  charts.acc=new Chart(document.getElementById('accChart'),{type:'line',data:{labels:[],datasets:[{label:'Val Accuracy',data:[],borderColor:'#3498db',backgroundColor:'rgba(52,152,219,.1)'}]},options:{responsive:true,animation:false}});
}
function resetCharts(showAcc){
  ensureCharts();
  charts.loss.data.labels=[]; charts.loss.data.datasets[0].data=[]; charts.loss.update();
  charts.acc.data.labels=[]; charts.acc.data.datasets[0].data=[]; charts.acc.update();
  document.getElementById('accChart').style.display = showAcc?'block':'none';
}

/* ========= 載入訓練 CSV ========= */
document.getElementById('trainCsv').addEventListener('change', (e)=>{
    const file=e.target.files?.[0]; if(!file) return;
    Papa.parse(file,{ header:true, skipEmptyLines:true, complete:(res)=>{
      rawData=res.data; 
      columns=res.meta.fields || Object.keys(rawData[0]||{});
      
      // 產生目標欄位下拉
      const targetSel=document.getElementById('targetSelect'); 
      targetSel.innerHTML='';
      columns.forEach(c=>{
        const opt=document.createElement('option'); 
        opt.value=c; 
        opt.textContent=c; 
        targetSel.appendChild(opt);
      });
  
      // 產生變數設定表格
      const tbody=document.querySelector('#varTable tbody');
      tbody.innerHTML='';
      columns.forEach(c=>{
        const row=document.createElement('tr');
  
        // 欄位名稱
        const nameTd=document.createElement('td');
        nameTd.textContent=c;
  
        // 資料型態下拉
        const typeTd=document.createElement('td');
        const sel=document.createElement('select');
        sel.innerHTML=`
          <option value="auto">自動判斷</option>
          <option value="numeric">數值</option>
          <option value="category">類別</option>
        `;
        typeTd.appendChild(sel);
  
        // 是否作為特徵
        const featTd=document.createElement('td');
        const chk=document.createElement('input');
        chk.type='checkbox';
        chk.checked=true;
        featTd.appendChild(chk);
  
        row.appendChild(nameTd);
        row.appendChild(typeTd);
        row.appendChild(featTd);
        tbody.appendChild(row);
      });
  
      document.getElementById('trainPreview').textContent=`已載入：${file.name}（${rawData.length} 行 × ${columns.length} 欄）`;
    }});
  });
  
/* ========= 訓練 ========= */
document.getElementById('trainBtn').addEventListener('click', async ()=>{
  if(!rawData.length){ alert('請先上傳訓練 CSV'); return; }
  const target=document.getElementById('targetSelect').value;
  const modelSel=document.getElementById('modelSelect').value;  // 可能值：'auto','linear','logistic','mlp','deepmlp','poly','tabnet','wide_deep' 或 'tree','rf','knn','svm','nb'
  const epochs=parseInt(document.getElementById('epochs').value,10);
  const batchSize=parseInt(document.getElementById('batchSize').value,10);
  const lr=parseFloat(document.getElementById('lr').value);
  const ratio=Math.max(0.5, Math.min(0.95, parseFloat(document.getElementById('trainRatio').value)||0.8));
  const normalize=document.getElementById('normalize').checked;
  const statusEl=document.getElementById('status');
  statusEl.textContent='資料前處理中...';

  try{
    const { X, y, meta:prep } = prepareXY(rawData, target, normalize);
    meta=prep; meta.modelType=modelSel;
    const { Xtr,ytr,Xte,yte } = trainTestSplit(X,y,ratio);
    const inDim=Xtr[0].length;
// 模型類別判斷
const traditionalList = ['tree','rf','knn','svm','nb'];
const isTraditional = traditionalList.includes(modelSel);

// MLBundle 對應表
const modelMap = {
    tree: 'DecisionTreeClassifier',   // 這裡也可根據 meta.task 判斷要用 Regression
    rf: 'RandomForestClassifier',
    knn: 'KNN',
    svm: 'SVM',
    nb: 'NaiveBayes'
};

// 重置 UI
resetCharts(!isTraditional && meta.task === 'classification');
document.getElementById('metricsBox').style.display = 'block';
document.getElementById('bestMetric').textContent = '—';
document.getElementById('finalMetric').textContent = '—';
document.getElementById('downloadModelBtn').disabled = isTraditional; // 傳統 ML 不支援下載
document.getElementById('downloadMetaBtn').disabled = false;
document.getElementById('predictBtn').disabled = false;

if (isTraditional) {
    const modelClassName = modelMap[modelSel];
    if (!MLBundle[modelClassName]) {
        throw new Error(`MLBundle.${modelClassName} 沒有定義，請檢查 ml-bundle.js 是否正確打包`);
    }

    // 如果是回歸任務要換成 Regression 版本
    let ctorName = modelClassName;
    if (meta.task === 'regression') {
        ctorName = modelClassName.replace('Classifier', 'Regression');
    }

    // 建立傳統 ML
    traditionalModel = new MLBundle[ctorName](Xtr, ytr, { task: meta.task });

    tfModel?.dispose?.(); tfModel = null;

    // 驗證
    const pred = traditionalModel.predict(Xte);
    if (meta.task === 'classification') {
        const acc = pred.filter((p, i) => p === yte[i]).length / yte.length;
        document.getElementById('bestMetric').textContent = `Accuracy = ${acc.toFixed(4)}`;
        document.getElementById('finalMetric').textContent = `Test Accuracy = ${acc.toFixed(4)}`;
    } else {
        const mse = yte.reduce((s, yv, i) => s + Math.pow(yv - pred[i], 2), 0) / yte.length;
        document.getElementById('bestMetric').textContent = `MSE = ${mse.toFixed(6)}`;
        document.getElementById('finalMetric').textContent = `Test MSE = ${mse.toFixed(6)}`;
    }
    meta.mlModel = { type: modelSel, trained: true };
    statusEl.textContent = '✅ 傳統 ML 訓練完成';
    return;
}
      

    // TF.js 模型路徑
    traditionalModel=null; // 清掉傳統模型
    statusEl.textContent='訓練 TF.js 模型中...';
    let classes=null;
    let yTrT, yTeT;
    if(meta.task==='classification'){
      classes=meta.labelInfo.classes;
      yTrT=tf.tensor1d(ytr.map(v=>+v),'float32');
      yTeT=tf.tensor1d(yte.map(v=>+v),'float32');
    }else{
      yTrT=tf.tensor1d(ytr,'float32');
      yTeT=tf.tensor1d(yte,'float32');
    }
    tfModel?.dispose?.();
    tfModel = makeModel(inDim, meta.task, modelSel, classes?classes.length:1, lr);
    const xTr=tf.tensor2d(Xtr, undefined, 'float32');
    const xTe=tf.tensor2d(Xte, undefined, 'float32');

    let best = meta.task==='classification' ? 0 : Number.POSITIVE_INFINITY;
    await tfModel.fit(xTr, yTrT, {
      epochs, batchSize, shuffle:true, validationData:[xTe,yTeT],
      callbacks:{
        onEpochEnd:(_, logs)=>{
          charts.loss.data.labels.push(charts.loss.data.labels.length+1);
          charts.loss.data.datasets[0].data.push(logs.val_loss ?? logs.loss);
          charts.loss.update();
          if(meta.task==='classification' && (logs.val_accuracy!==undefined || logs.val_acc!==undefined)){
            const acc=logs.val_accuracy ?? logs.val_acc;
            charts.acc.data.labels.push(charts.acc.data.labels.length+1);
            charts.acc.data.datasets[0].data.push(acc); charts.acc.update();
            if(acc>best) best=acc;
            document.getElementById('bestMetric').textContent=`Best Val Acc = ${best.toFixed(4)}`;
            document.getElementById('finalMetric').textContent=`Val Acc = ${(acc??0).toFixed(4)}`;
          }else{
            const cur=logs.val_loss ?? logs.loss;
            if(cur<best) best=cur;
            document.getElementById('bestMetric').textContent=`Best Val MSE = ${best.toFixed(6)}`;
            document.getElementById('finalMetric').textContent=`Val MSE = ${cur.toFixed(6)}`;
          }
        },
        onTrainEnd:()=>{ statusEl.textContent='✅ 訓練完成（TF.js）'; document.getElementById('downloadModelBtn').disabled=false; }
      }
    });
    xTr.dispose(); xTe.dispose(); yTrT.dispose(); yTeT.dispose();

  }catch(err){
    document.getElementById('status').textContent='❌ 訓練失敗：'+err.message;
    console.error(err);
  }
});

/* ========= 下載模型 / metadata ========= */
document.getElementById('downloadModelBtn').addEventListener('click', async ()=>{
  if(!tfModel){ alert('目前模型不可下載（傳統 ML 不支援或尚未訓練 TF.js 模型）'); return; }
  try{ await tfModel.save('downloads://tfjs_model'); }catch(e){ alert('下載失敗：'+e.message); }
});
document.getElementById('downloadMetaBtn').addEventListener('click', ()=>{
  if(!meta) return; downloadBlob('metadata.json', JSON.stringify(meta,null,2), 'application/json');
});

/* ========= 預測 ========= */
document.getElementById('predictBtn').addEventListener('click', ()=>{
  const pf=document.getElementById('predictCsv').files?.[0];
  if(!meta){ alert('請先完成訓練'); return; }
  if(!pf){ alert('請上傳要預測的 CSV'); return; }
  const status=document.getElementById('predictStatus'); status.textContent='資料處理中...';
  Papa.parse(pf,{ header:true, skipEmptyLines:true, complete:(res)=>{
    try{
      const rows=res.data;
      const Xnew=transformFeatures(rows, meta);
      // 傳統 ML
      if(traditionalModel){
        const pred = traditionalModel.predict(Xnew);
        if(meta.task==='classification' && meta.labelInfo){
          const out = rows.map((r,i)=>({...r, 預測值: meta.labelInfo.classes[pred[i]] ?? pred[i]}));
          lastPredRows=out;
        }else{
          lastPredRows = rows.map((r,i)=>({...r, 預測值: pred[i]}));
        }
        renderTable('predictTable', lastPredRows.slice(0,100));
        status.textContent='✅ 完成（傳統 ML）';
        document.getElementById('downloadPredBtn').disabled=false;
        return;
      }
      // TF.js
      if(!tfModel){ alert('請先以 TF.js 訓練或載入模型'); return; }
      const x = tf.tensor2d(Xnew, undefined, 'float32');
      const p = tfModel.predict(x);
      if(meta.task==='classification'){
        const probs=p.arraySync();
        const cls=meta.labelInfo.classes;
        const idx=probs.map(v=> Array.isArray(v) && v.length>1 ? v.indexOf(Math.max(...v)) : (v>0.5?1:0));
        lastPredRows = rows.map((r,i)=>({...r, 預測值: cls[idx[i]] ?? idx[i]}));
      }else{
        const vals=p.arraySync().map(v=> Array.isArray(v)?v[0]:v);
        lastPredRows = rows.map((r,i)=>({...r, 預測值: vals[i]}));
      }
      x.dispose(); p.dispose();
      renderTable('predictTable', lastPredRows.slice(0,100));
      status.textContent='✅ 完成（TF.js）';
      document.getElementById('downloadPredBtn').disabled=false;
    }catch(e){
      status.textContent='❌ 預測失敗：'+e.message;
      console.error(e);
    }
  }});
});
document.getElementById('downloadPredBtn').addEventListener('click', ()=>{
  if(!lastPredRows.length) return;
  const csv=toCSV(lastPredRows);
  downloadBlob('predictions.csv', csv, 'text/csv');
});
